	var filter=new Array(5);
   var gerichte = new Array(20); /* 
   
   
   
   i,0,0: Name
   i,1,var: Filter: 1) Vegan, 2) Vegetarisch, 3) Gluten-frei, 4) Laktosefrei, 5) Nussfrei, 6) Ei-frei*/
   
 window.onload=function datum_abrufen()
 {
	var jetzt = new Date();
	var Tag = jetzt.getDate();
	var Jahresmonat = jetzt.getMonth();
	var Monat = new Array("Januar", "Februar", "März", "April", "Mai", "Juni","Juli", "August", "September", "Oktober", "November", "Dezember");

	document.getElementById("aktuelles_Datum").innerHTML="Heute, " + Tag + ". " + Monat[Jahresmonat];
	for (var i=0; i<=5; i++) 
	{
		filter[i]=new Array;
	}
	   for (var i=0; i<13; i++) 
	   {
		   gerichte[i]= new Array;
		   gerichte[i][0]= new Array;
		   gerichte[i][1]= new Array;
		   
		   

		   gerichte[i][0][0]="Salmon";
		   
		   gerichte[i][1][0]="no";
		   gerichte[i][1][1]="yes";
		   gerichte[i][1][2]="yes";
		   gerichte[i][1][3]="no";
		   gerichte[i][1][4]="no";
		   
		   gerichte[i][1][5]="yes";
		   
		   

	   }
	   
	   gerichte[12][1][1]="no";
	   
	   

	   	var maxim= document.getElementsByClassName("gericht_auswahl");
	for (var i = 0; maxim.length; i++)
	{

		variable = "<img src='file:///D:/Users/maximilian_fischer/Documents/Munchery/Website/Bild_1.jpg'	width=100%><br>Shrimp1";			
			
		if(gerichte[i][1][0]=="yes")
		{
			variable = variable+ "<img src='file:///D:/Users/maximilian_fischer/Documents/Munchery/Website/vegan.png'  width='15' height='15'/></img><br>";		
		}
		
		if(gerichte[i][1][1]=="yes")
		{
			variable = variable+ "<img src='file:///D:/Users/maximilian_fischer/Documents/Munchery/Website/vegetarian.png'  width='15' height='15'/></img>";		
		}
		
		if(gerichte[i][1][2]=="yes")
		{
			variable = variable+ "<img src='file:///D:/Users/maximilian_fischer/Documents/Munchery/Website/gluten-free.png'  width='15' height='15'/></img>";		
		}
		if(gerichte[i][1][3]=="yes")
		{
			variable = variable+ "<img src='file:///D:/Users/maximilian_fischer/Documents/Munchery/Website/dairy-free.png'  width='15' height='15'/></img>";		
		}
		
		if(gerichte[i][1][4]=="yes")
		{
			variable = variable+ "<img src='file:///D:/Users/maximilian_fischer/Documents/Munchery/Website/nut-free.png'  width='15' height='15'/></img>";		
		}
		
		if(gerichte[i][1][5]=="yes")
		{
			variable = variable+ "<img src='file:///D:/Users/maximilian_fischer/Documents/Munchery/Website/egg-free.png'  width='15' height='15'/></img>";		
		}
			variable=variable+"<br><br>";
			maxim[i].innerHTML=variable;
	}
	   
	 
 }
   
   
   
function filter_(clicked_id)
{

	var maxim= document.getElementsByClassName("box");
	var filter_var=document.getElementsByClassName("filter");

	if(filter_var[clicked_id].style.backgroundColor=="")
	{

		filter_var[clicked_id].style.backgroundColor="#e6e6e6";
		filter[clicked_id]=1;
		
		j=0;
		i=0;
		var nicht_zeigen=0;
		while(i<maxim.length)	
		{
			nicht_zeigen=0;
			j=0;
			while(j<=5)
			{
				if (filter[j]==1 && gerichte[i][1][j]=="no")
				{
					nicht_zeigen=1;
				}
				j=j+1;
			}
			
			if(nicht_zeigen==1)
			{
				
				maxim[i].style.display="none";	
				
			}
			else
			{
				maxim[i].style.display="block";	
				
			}
			i=i+1;
		}	
	}
	else
	{

		var nicht_zeigen=0;
		filter_var[clicked_id].style.backgroundColor="";
		filter[clicked_id]=0;

		
		j=0;
		i=0;
		while(i<maxim.length)	
		{
			nicht_zeigen=0;
			j=0;
			while(j<=5)
			{
				if (filter[j]==1 && gerichte[i][1][j]=="no")
				{
					nicht_zeigen=1;
				}
				j=j+1;
			}
			
			if(nicht_zeigen==1)
			{
				
				maxim[i].style.display="none";	
				
			}
			else
			{
				maxim[i].style.display="block";	
				
			}
			i=i+1;
		}								

	}
	

}





function datum_auswahl() 	
{
	
	
		var maxim= document.getElementsByClassName("datum_auswahl");
		
		
		var jetzt = new Date();
		var Tag = jetzt.getDate();
		var Jahresmonat = jetzt.getMonth();
		var TagInWoche = jetzt.getDay();
		var Wochentag = new Array("SO", "MO", "DI", "MI",
		"DO", "FR", "SA");
		j=0;
		tage=jetzt.getDate();

		var day = jetzt.getDate();

		
		ausgewaehlter_tag=6; /* hier eintragen, auf welchen Tag User geklick hat */
		

		var DatumZeitJetzt = new Date();
		var DatumZukunft = new Date();
		var DatumZukunft_ = new Date();
		
		var AnzahlTage = 0;
		var msProTag = 86400000;

		DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);
		auswahl_tag=0;
		
		DatumZukunft.setTime(DatumZeitJetzt.getTime() + ausgewaehlter_tag * msProTag);
		TagInWoche = DatumZukunft.getDay();
		
		
		if (TagInWoche == 6 || TagInWoche == 0)
		{
				ausgewaehlter_tag=ausgewaehlter_tag+1;
		}
		
		
		var TagInWoche = jetzt.getDay();
		
		while(auswahl_tag<ausgewaehlter_tag)
		{
			if (TagInWoche == 6 || TagInWoche == 0)
			{
				
				TagInWoche=1;
				AnzahlTage=AnzahlTage+1;
				DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);
			}
			else
			{
				
				TagInWoche=TagInWoche+1;
				AnzahlTage=AnzahlTage+1;
				DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);				
			}
				

			auswahl_tag=auswahl_tag+1;

			
		}
		

		
		maxim[auswahl_tag].innerHTML="<div class='box_datum'><a class='box_datum_css_haupt' href='' ><font size='0.5' color='#808080'>"+Wochentag[TagInWoche]+"</font><br>"+DatumZukunft.getDate()+"</a></div>";
	
		TagInWoche=TagInWoche+1;
		AnzahlTage=AnzahlTage+1;
		DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);
		j=j+1;
		auswahl_tag=auswahl_tag+1;
		if(auswahl_tag>6)
		{
							auswahl_tag=0;
				AnzahlTage=0;
				DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);
				TagInWoche = DatumZukunft.getDay();
			
		}
		
		while (j<7)
		{
			if (TagInWoche == 6 || TagInWoche == 0)
			{
				DatumZukunft_.setTime(DatumZukunft.getTime() + 1 * msProTag);
				maxim[auswahl_tag].innerHTML="<div class='box_datum'><div class='box_datum_css_wochenende'><font size='0.5' color='#808080'>Geschlossen</font><br>"+"<font color='#808080'>"+DatumZukunft.getDate()+"-"+DatumZukunft_.getDate()+"</div></div>";
				TagInWoche=1;
				AnzahlTage=AnzahlTage+1;
				DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);

			}
			else
			{

				maxim[auswahl_tag].innerHTML="<div class='box_datum'><a class='box_datum_css' href='' ><font size='1.5' color='#808080'>"+Wochentag[TagInWoche]+"</font><br>"+DatumZukunft.getDate()+"</a></div>";
			
				TagInWoche=TagInWoche+1;
				AnzahlTage=AnzahlTage+1;
				DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);
			}
		
			j=j+1;
			auswahl_tag=auswahl_tag+1;
			if(auswahl_tag>6)
			{
				auswahl_tag=0;
				AnzahlTage=0;
				DatumZukunft.setTime(DatumZeitJetzt.getTime() + AnzahlTage * msProTag);
				TagInWoche = DatumZukunft.getDay();
				
			}
		}
}

 


 
 
 
 function arrow_laden_filter(id) 
{

	var maxim= document.getElementsByClassName("arrow_filter");
	if (id==0)
	{
		variable = "arrow_up.png";	
		maxim[0].src=variable;

	}
	else
	{
		variable = "arrow_down.png";	
		maxim[0].src=variable;

		
	}
		
	
 }
 
  function arrow_laden_plz(id) 
{

	var maxim= document.getElementsByClassName("arrow_plz");
	if (id==0)
	{
		variable = "arrow_up.png";	
		maxim[0].src=variable;

	}
	else
	{
		variable = "arrow_down.png";	
		maxim[0].src=variable;

		
	}
		
	
 }
 
 
   function arrow_laden_datum(id) 
{

	var maxim= document.getElementsByClassName("arrow_plz");
	if (id==0)
	{
		variable = "arrow_up.png";	
		maxim[1].src=variable;

	}
	else
	{
		variable = "arrow_down.png";	
		maxim[1].src=variable;

		
	}
		
	
 }
 
 
 
 function submit_zip()
 
 {
	 

		var submit_plz_input=document.getElementById("eingabe1").value;
		if(isNaN(submit_plz_input) ==true || submit_plz_input.length<5)
		{
			document.getElementById("plz_fehler").innerHTML="Bitte eine fünfstellige PLZ angeben";
		}
		else
		{
			
				document.getElementById("plz_fehler").innerHTML="";

			
		}
	 
	 
	 
	 
 }
 
 
 
 
 
 
 
 function overlay() {
	
	
		var submit_plz_input=document.getElementById("eingabe1").value;
		if(isNaN(submit_plz_input) ==true || submit_plz_input.length<5)
		{
			document.getElementById("plz_fehler").innerHTML="Bitte eine fünfstellige PLZ angeben";
		}
		else
		{
			
			el = document.getElementById("overlay");
			el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
			document.getElementById("x-mask").style.opacity="0.4";
			document.getElementById("plz_fehler").innerHTML="";
			
		}


	
	
	


}

window.onscroll = function () 
{
	el = document.getElementById("overlay");
	
	if (el.style.visibility =="visible")
	{
		window.scrollTo(0, 0);
	}
}


 function warteliste_click() {
	el = document.getElementById("overlay");
	el.style.visibility = (el.style.visibility == "hidden") ? "visible" : "hidden";
	document.getElementById("x-mask").style.opacity="1.0";
}



 function warteliste_click_schliessen() {

	el = document.getElementById("overlay");
	el.style.visibility = (el.style.visibility == "hidden") ? "visible" : "hidden";
	document.getElementById("x-mask").style.opacity="1.0";
}


	
 
 function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    
  }
}

 
 
 
 
 
 
 
function mouse_effect_in(clicked_id) 
{

	var maxim= document.getElementsByClassName("box_zusatz_2");

	maxim[clicked_id-1].value="+ ADD";


 }
 
 


function input_plz_text() 
{
	
	
		if(document.getElementById("eingabe1").value=="PLZ")
		{
			
			
			document.getElementById("eingabe1").value="";
			document.getElementById("eingabe1").style.color="#000000";
			document.getElementById("plz_fehler").innerHTML="";
			
		}
 }
 
 
 function input_plz_text_blur() 
{
	if(document.getElementById("eingabe1").value=="")
	{
		document.getElementById("eingabe1").value="PLZ";
		document.getElementById("eingabe1").style.color="#808080"
		document.getElementById("plz_fehler").innerHTML="";
	}
	

 }
 




 
function mouse_effect_out(clicked_id) 
{

		var maxim= document.getElementsByClassName("box_zusatz_2");
	maxim[clicked_id-1].value="+";
 }
 

 
 
 function filter_function() {
	if (document.getElementById("filter_dropdown").style.display=="block")
	{
		document.getElementById("myDropdown").style.display = "none";
		document.getElementById("myDropdown_").style.display = "none";
		document.getElementById("filter_dropdown").style.display = "none";
		
		arrow_laden_plz(0);
		arrow_laden_datum(0);
		arrow_laden_filter(0);
		
	}
	else
	{
		document.getElementById("filter_dropdown").style.display = "block";
		document.getElementById("myDropdown_").style.display = "none";
		document.getElementById("myDropdown").style.display = "none";
		
		arrow_laden_plz(0);
		arrow_laden_datum(0);
		arrow_laden_filter(1);
		
	}
} 

 

 
 
function myFunction() {
	if (document.getElementById("myDropdown").style.display=="block")
	{
		document.getElementById("myDropdown").style.display = "none";
		document.getElementById("myDropdown_").style.display = "none";
		document.getElementById("filter_dropdown").style.display = "none";
		arrow_laden_plz(0);
		arrow_laden_datum(0);
		arrow_laden_filter(0);
	}
	else
	{
		document.getElementById("myDropdown").style.display = "block";
		document.getElementById("myDropdown_").style.display = "none";
		document.getElementById("filter_dropdown").style.display = "none";
		arrow_laden_plz(0);
		arrow_laden_datum(1);
		arrow_laden_filter(0);
		
	}
}



function myFunction_() {
	
	if (document.getElementById("myDropdown_").style.display=="block")
	{
		document.getElementById("myDropdown_").style.display = "none";
		document.getElementById("myDropdown").style.display = "none";
		document.getElementById("filter_dropdown").style.display = "none";

		arrow_laden_plz(0);
		arrow_laden_datum(0);
		arrow_laden_filter(0);

	}
	else
	{
		
		document.getElementById("myDropdown_").style.display = "block";
		document.getElementById("myDropdown").style.display = "none";
		document.getElementById("filter_dropdown").style.display = "none";

		arrow_laden_plz(1);
		arrow_laden_datum(0);
		arrow_laden_filter(0);
	}	
}

// Close the dropdown if the user clicks outside of it
/*window.onclick = function(e) {
  
  
  if (!e.target.matches('.dropbtn_datum')) {
	arrow_laden();
    var dropdowns = document.getElementsByClassName("dropdown-content");
    for (var d = 0; d < dropdowns.length; d++) {
      var openDropdown = dropdowns[d];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}*/






 
 
 
 
